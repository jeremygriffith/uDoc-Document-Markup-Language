// OmniHelp message text for top nav, US English version, OHver 0.8
// Copyright (c) 2006 by Jeremy H. Griffith.  All rights reserved.

// ohtop.js
var HideButTxt = 'Hide'
var HideButTitle = 'Hide navigation frame'
var ShowButTxt = 'Show'
var ShowButTitle = 'Show navigation frame'
var HideShowTxt = 'Hide/Show'
var StartButTxt = 'Start'
var StartButTitle = 'Go to starting topic'
var PrevButTxt = 'Prev'
var PrevButTitle = 'Go to previous topic'
var NextButTxt = 'Next'
var NextButTitle = 'Go to next topic'
var BackButTxt = 'Back'
var BackButTitle = 'Back up to last topic'
var FwdButTxt = 'Fwd'
var FwdButTitle = 'Undo last Back up'

// see also ohlang.js or oxlang.js for frameset,
// and ohlangct.js for ctrl

// end of ohlangtp.js for US English
